exports.mainAddress = "0x67ef6848ab6c930e7d77078edf7053368cf3003e";                // 토큰 생성 계정
exports.makerAddress = "0xd855746510fd6fd4b20b6bdf9d170572ba2acc04";               // 제작자 계정
exports.eoaAddress = "0xdbb5a9a5eeca3c667459b64a638bcf34a4b7fbe9";                 // 참여자 계정
exports.TokenContractAddress = "0xcfc09aad76d55543b587f11294bfb81f80f9f8cd";       // 토큰 계정
exports.crowdFundContractAddress ="0x0bf7da7ae67360f276a025d3b39cf4a7924a4a6f";    // 펀딩 계정
