#/bin/sh
${HOME}/Library/Application\ Support/Mist/binaries/Geth/unpacked/geth --dev --ipcpath test-net/geth.ipc --datadir test-data --networkid 1234 --rpc --rpcport 8545
