#/bin/sh
/Applications/Mist.app/Contents/MacOS/Mist --rpc test-net/geth.ipc
