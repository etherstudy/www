#!/bin/sh
export PATH=${HOME}/Library/Application\ Support/Mist/binaries/Geth/unpacked:${PATH}