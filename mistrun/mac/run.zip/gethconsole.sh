#/bin/sh
${HOME}/Library/Application\ Support/Mist/binaries/Geth/unpacked/geth attach test-net/geth.ipc
